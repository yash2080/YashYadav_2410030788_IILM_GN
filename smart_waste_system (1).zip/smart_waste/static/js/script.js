/* ═══════════════════════════════════════════════════════════════════════════
   SMART WASTE CLASSIFICATION SYSTEM  ·  script.js
   Global scripts: animations, nav scroll, stat counters
   ═══════════════════════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* ── NAV SHADOW ON SCROLL ─────────────────────────────────────────────── */
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.style.boxShadow = window.scrollY > 10
        ? '0 2px 20px rgba(0,0,0,.08)'
        : 'none';
    }, { passive: true });
  }

  /* ── ANIMATED STAT COUNTERS ─────────────────────────────────────────────── */
  function animateCounter(el, target, suffix = '', duration = 1200) {
    let start = 0;
    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = (target % 1 !== 0
        ? (eased * target).toFixed(1)
        : Math.round(eased * target)) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const raw = el.dataset.count;
      if (!raw) return;
      const num = parseFloat(raw);
      const suffix = el.dataset.suffix || '';
      animateCounter(el, num, suffix);
      observer.unobserve(el);
    });
  }, { threshold: 0.3 });

  document.querySelectorAll('[data-count]').forEach(el => observer.observe(el));

  /* ── SCROLL REVEAL ──────────────────────────────────────────────────────── */
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.stat-card, .step-card, .hstat-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity .5s ease, transform .5s ease';
    revealObserver.observe(el);
  });

  // Add 'revealed' CSS handling
  const style = document.createElement('style');
  style.textContent = `.revealed { opacity: 1 !important; transform: translateY(0) !important; }`;
  document.head.appendChild(style);

  /* ── FLASH MESSAGES ─────────────────────────────────────────────────────── */
  document.querySelectorAll('.flash-msg').forEach(el => {
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(-10px)';
      el.style.transition = 'opacity .4s, transform .4s';
      setTimeout(() => el.remove(), 400);
    }, 3500);
  });

});
